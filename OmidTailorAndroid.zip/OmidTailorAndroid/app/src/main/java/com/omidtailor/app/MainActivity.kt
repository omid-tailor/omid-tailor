package com.omidtailor.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.launch
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore
import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

private val Context.dataStore by preferencesDataStore(name = "omid_orders")
private val Gold = Color(0xFFD6B35A)
private val Dark = Color(0xFF101010)
private val Panel = Color(0xFF1D1D1D)
private val Muted = Color(0xFFB7B1A2)
private val White = Color(0xFFF7F4EA)

data class Order(
    val id: Long, val name: String, val phone: String, val type: String,
    val price: Long, val paid: Long, val due: String, val status: String,
    val measurements: String
) { val remaining: Long get() = (price - paid).coerceAtLeast(0) }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { OmidApp(this) }
    }
}

@Composable
fun OmidApp(context: Context) {
    val scope = rememberCoroutineScope()
    var orders by remember { mutableStateOf(listOf<Order>()) }
    var tab by remember { mutableStateOf(0) }
    var showAdd by remember { mutableStateOf(false) }
    var search by remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        context.dataStore.data.collect { prefs ->
            val raw = prefs[stringPreferencesKey("orders")] ?: "[]"
            orders = runCatching {
                val arr = JSONArray(raw)
                (0 until arr.length()).map { i ->
                    val o = arr.getJSONObject(i)
                    Order(o.getLong("id"), o.getString("name"), o.optString("phone"),
                        o.getString("type"), o.getLong("price"), o.getLong("paid"),
                        o.optString("due"), o.optString("status", "در حال دوخت"),
                        o.optString("measurements"))
                }
            }.getOrDefault(emptyList())
        }
    }
    fun save(list: List<Order>) {
        orders = list
        val arr = JSONArray()
        list.forEach { o -> arr.put(JSONObject().apply {
            put("id", o.id); put("name", o.name); put("phone", o.phone); put("type", o.type)
            put("price", o.price); put("paid", o.paid); put("due", o.due)
            put("status", o.status); put("measurements", o.measurements)
        }) }
        scope.launch { context.dataStore.edit { it[stringPreferencesKey("orders")] = arr.toString() } }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Gold, onPrimary = Dark, background = Dark, surface = Panel,
        onSurface = White, secondary = Muted
    )) {
        CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
            Scaffold(containerColor = Dark, bottomBar = {
                NavigationBar(containerColor = Panel, contentColor = Gold) {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 },
                        icon = { Icon(Icons.Default.Dashboard, null) }, label = { Text("داشبورد") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 },
                        icon = { Icon(Icons.Default.ListAlt, null) }, label = { Text("سفارش‌ها") })
                }
            }, floatingActionButton = {
                FloatingActionButton(onClick = { showAdd = true }, containerColor = Gold, contentColor = Dark) {
                    Icon(Icons.Default.Add, "ثبت سفارش")
                }
            }) { pad ->
                Column(Modifier.fillMaxSize().padding(pad).padding(horizontal = 18.dp)) {
                    Header()
                    if (tab == 0) Dashboard(orders, onOrders = { tab = 1 })
                    else {
                        OutlinedTextField(value = search, onValueChange = { search = it },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            placeholder = { Text("جستجوی نام یا شماره مشتری") },
                            leadingIcon = { Icon(Icons.Default.Search, null, tint = Gold) },
                            colors = fieldColors())
                        Spacer(Modifier.height(12.dp))
                        OrderList(orders.filter { it.name.contains(search, true) || it.phone.contains(search) }, onStatus = { order, status ->
                            save(orders.map { if (it.id == order.id) it.copy(status = status) else it })
                        })
                    }
                }
            }
            if (showAdd) AddOrderDialog(onDismiss = { showAdd = false }, onSave = {
                save(listOf(it) + orders); showAdd = false; tab = 1
            })
        }
    }
}

@Composable
fun Header() {
    Row(Modifier.fillMaxWidth().padding(top = 20.dp, bottom = 22.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(14.dp), color = Gold.copy(alpha = .15f), modifier = Modifier.size(48.dp)) {
            Box(contentAlignment = Alignment.Center) { Icon(Icons.Default.ContentCut, null, tint = Gold, modifier = Modifier.size(27.dp)) }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("OMID TAILOR", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
            Text("مدیریت خیاطی و پارچه‌فروشی امید", color = Muted, fontSize = 12.sp)
        }
        Text("۱.۰", color = Muted, fontSize = 12.sp)
    }
}

@Composable
fun Dashboard(orders: List<Order>, onOrders: () -> Unit) {
    val unpaid = orders.sumOf { it.remaining }
    val delivered = orders.count { it.status == "تحویل‌شده" }
    Text("صفحه مدیریت", color = White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
    Text("خلاصه وضعیت کسب‌وکار شما", color = Muted, modifier = Modifier.padding(top = 4.dp, bottom = 18.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatCard("مجموع سفارش‌ها", orders.size.toString(), Modifier.weight(1f))
        StatCard("تحویل‌شده", delivered.toString(), Modifier.weight(1f))
    }
    Spacer(Modifier.height(10.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        StatCard("باقی‌مانده حساب", "${unpaid} افغانی", Modifier.weight(1f))
        StatCard("در حال دوخت", orders.count { it.status == "در حال دوخت" }.toString(), Modifier.weight(1f))
    }
    Spacer(Modifier.height(22.dp))
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text("آخرین سفارش‌ها", color = Gold, fontWeight = FontWeight.Bold, fontSize = 18.sp, modifier = Modifier.weight(1f))
        TextButton(onClick = onOrders) { Text("همه سفارش‌ها", color = Gold) }
    }
    OrderList(orders.take(4), onStatus = { _, _ -> })
}

@Composable
fun StatCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(modifier, colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(18.dp), border = BorderStroke(1.dp, Gold.copy(alpha = .25f))) {
        Column(Modifier.padding(15.dp).fillMaxWidth()) {
            Text(title, color = Muted, fontSize = 13.sp)
            Spacer(Modifier.height(14.dp))
            Text(value, color = Gold, fontWeight = FontWeight.Bold, fontSize = 23.sp)
        }
    }
}

@Composable
fun OrderList(orders: List<Order>, onStatus: (Order, String) -> Unit) {
    if (orders.isEmpty()) {
        Box(Modifier.fillMaxWidth().padding(30.dp), contentAlignment = Alignment.Center) {
            Text("هنوز سفارشی ثبت نشده است", color = Muted)
        }
    } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 90.dp)) {
        items(orders, key = { it.id }) { o ->
            Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, Gold.copy(alpha = .18f))) {
                Column(Modifier.fillMaxWidth().padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(o.name, color = White, fontWeight = FontWeight.Bold, fontSize = 17.sp, modifier = Modifier.weight(1f))
                        Text(o.status, color = Gold, fontSize = 12.sp)
                    }
                    Text("${o.type}  •  ${o.phone}", color = Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 5.dp))
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("قیمت: ${o.price}", color = White, fontSize = 12.sp)
                        Text("پرداخت: ${o.paid}", color = Muted, fontSize = 12.sp)
                        Text("باقی: ${o.remaining}", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    if (o.due.isNotBlank()) Text("تاریخ تحویل: ${o.due}", color = Muted, fontSize = 12.sp)
                    var expanded by remember { mutableStateOf(false) }
                    Box {
                        TextButton(onClick = { expanded = true }) { Text("تغییر وضعیت", color = Gold) }
                        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                            listOf("در حال دوخت", "آماده تحویل", "تحویل‌شده", "زیر ترمیم").forEach { s ->
                                DropdownMenuItem(text = { Text(s) }, onClick = { onStatus(o, s); expanded = false })
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AddOrderDialog(onDismiss: () -> Unit, onSave: (Order) -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    var type by remember { mutableStateOf("پیراهن‌تنبان") }; var price by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("0") }; var due by remember { mutableStateOf("") }
    var measurements by remember { mutableStateOf("") }
    var error by remember { mutableStateOf("") }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth(.94f).fillMaxHeight(.88f)) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(18.dp)) {
                Text("ثبت سفارش جدید", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                FormField("نام مشتری *", name, { name = it })
                FormField("شماره تماس", phone, { phone = it }, KeyboardType.Phone)
                Text("نوع لباس", color = Gold, modifier = Modifier.padding(top = 8.dp, bottom = 6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("پیراهن‌تنبان", "واسکت", "دریشی").forEach { t ->
                        FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t, fontSize = 11.sp) },
                            colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = Dark))
                    }
                }
                FormField("قیمت کل (افغانی) *", price, { price = it }, KeyboardType.Number)
                FormField("پیش‌پرداخت", paid, { paid = it }, KeyboardType.Number)
                FormField("تاریخ تحویل", due, { due = it })
                FormField("اندازه‌ها و یادداشت‌ها", measurements, { measurements = it }, singleLine = false)
                if (error.isNotBlank()) Text(error, color = Color(0xFFFF7777))
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("انصراف") }
                    Button(onClick = {
                        val p = price.toLongOrNull(); val d = paid.toLongOrNull() ?: 0
                        if (name.isBlank() || p == null || p < 0 || d < 0) error = "نام و قیمت معتبر را وارد کنید"
                        else onSave(Order(System.currentTimeMillis(), name.trim(), phone.trim(), type, p, d.coerceAtMost(p), due.trim(), "در حال دوخت", measurements.trim()))
                    }, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Dark)) { Text("ذخیره سفارش") }
                }
            }
        }
    }
}

@Composable
fun FormField(label: String, value: String, onValue: (String) -> Unit,
              keyboard: KeyboardType = KeyboardType.Text, singleLine: Boolean = true) {
    OutlinedTextField(value = value, onValueChange = onValue, label = { Text(label) },
        modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), singleLine = singleLine,
        minLines = if (singleLine) 1 else 3, keyboardOptions = KeyboardOptions(keyboardType = keyboard),
        colors = fieldColors())
}

@Composable
fun fieldColors() = OutlinedTextFieldDefaults.colors(
    focusedBorderColor = Gold, unfocusedBorderColor = Color(0xFF555044),
    focusedLabelColor = Gold, unfocusedLabelColor = Muted,
    focusedTextColor = White, unfocusedTextColor = White,
    cursorColor = Gold, focusedPlaceholderColor = Muted, unfocusedPlaceholderColor = Muted
)
